import{a as t}from"../chunks/entry.BrX5Sf1r.js";export{t as start};

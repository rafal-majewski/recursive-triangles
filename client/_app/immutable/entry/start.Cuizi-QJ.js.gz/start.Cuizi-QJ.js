import{a as t}from"../chunks/entry.BmlftndO.js";export{t as start};
